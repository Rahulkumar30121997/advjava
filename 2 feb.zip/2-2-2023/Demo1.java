// program showing the concept of getter and setter methods
import java.util.Scanner;
class Student
{
	private int rno;
	private double per;
	private String name;
	
	// getter method
	public int getRno() {
		return rno;
	}
	
	// setter method
	public void setRno(int rno) {
		this.rno = rno;
	}

	// getter method
	public double getPer() {
		return per;
	}

	// setter method
	public void setPer(double per) {
		this.per = per;
	}
	
	// getter method
	public String getName() {
		return name;
	}
	
	// setter method
	public void setName(String name) {
		this.name = name;
	}
}
class Demo1
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		Student s = new Student();
		
		System.out.println("Enter Student name : ");
		String name = sc.nextLine();
		
		System.out.println("Enter roll number : ");
		int rno = sc.nextInt();
		
		System.out.println("Enter percentage : ");
		double per = sc.nextDouble();
		
		s.setName(name);
		s.setPer(per);
		s.setRno(rno);
		
		System.out.println("Roll number : "+s.getRno());
		System.out.println("Percentage : "+s.getPer());
		System.out.println("Name : "+s.getName());
	}
}