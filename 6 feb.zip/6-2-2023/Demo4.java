
public class Demo4
{
	static void myMethod(Integer i,int j,Float f)
	{
		System.out.println("object : "+(i+45));
		System.out.println("value : "+j);		
		System.out.println("null value : "+f);
		System.out.println("class Name : "+i.getClass().getName());
	}
	public static void main(String args[])
	{
		myMethod(100,new Integer(200),null);
	}
}
