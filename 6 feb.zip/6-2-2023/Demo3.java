
public class Demo3 
{
	static void myMethod1(Integer i)
	{
		System.out.println("object : "+i);
	}
	static void myMethod2(int i)
	{
		System.out.println("value : "+i);		
	}
	static void myMethod3(Double d)
	{
		System.out.println("null value : "+d);
	}
	public static void main(String args[])
	{
		myMethod1(100);
		myMethod2(new Integer(200));
		myMethod3(null);
	}
}
