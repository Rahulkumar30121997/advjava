// program showing the concept of Wrapper class

class Demo1
{
	public static void main(String args[])
	{
		// conversion of primitive datatype into object of wrapper class
		int num = 100;
		Integer obj = Integer.valueOf(num);
		System.out.println("value : "+num);
		System.out.println("object : "+obj);
		
		Integer obj1 = new Integer(200);
		System.out.println("\nvalue : "+num);
		System.out.println("object : "+obj1);
		
		// conversion of object into its respective primitive datatype
		int num1 = obj.intValue();
		int num2 = obj1.intValue();
		System.out.println(num1+"\t"+num2);
		
		
	}
}