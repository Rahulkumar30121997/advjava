// program showing the concept of getter and setter methods
import java.util.Scanner;
class StudentDemo
{
	private int rno;
	private double per;
	private String name;
	
	// getter method
	public int getRno() {
		return rno;
	}
	
	// getter method
	public double getPer() {
		return per;
	}

	// setter method
	public void setPer(double per) {
		this.per = per;
	}
	
	// getter method
	public String getName() {
		return name;
	}
	
	// setter method
	public void setName(String name) {
		this.name = name;
	}
	// constructor injection
	public StudentDemo(int rno)
	{
		this.rno=rno;
	}
}
class Demo2
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Student name : ");
		String name = sc.nextLine();
		
		System.out.println("Enter roll number : ");
		int rno = sc.nextInt();
		
		System.out.println("Enter percentage : ");
		double per = sc.nextDouble();

		StudentDemo s = new StudentDemo(rno);

		s.setName(name);
		s.setPer(per);
		s.setPer(45.56); // limitation of setter injection
		
		System.out.println("Roll number : "+s.getRno());
		System.out.println("Percentage : "+s.getPer());
		System.out.println("Name : "+s.getName());
	}
}