// program showing the concept of Wrapper class

class Demo2
{
	public static void main(String args[])
	{
		// conversion of primitive datatype into object of wrapper class
		int num = 100;
		Integer obj = num; // autoboxing
		System.out.println("value : "+num);
		System.out.println("object : "+obj);
		
		// conversion of object into its respective primitive datatype
		Integer obj1 = 200; // autoboxing
		int num1 = obj1; // unboxing
		System.out.println("value : "+num1);
		System.out.println("object : "+obj);
		
		
	}
}