
public class Demo5
{
	public static void main(String args[])
	{
		char ch = 'a';
		System.out.println("Alphabetic : "+Character.isAlphabetic(ch));
		System.out.println("Digit : "+Character.isDigit(ch));
		System.out.println("Space : "+Character.isSpace(ch));
		System.out.println("WhiteSpace : "+Character.isWhitespace(ch));
		System.out.println("UpperCase : "+Character.isUpperCase(ch));
		System.out.println("LowerCase : "+Character.isLowerCase(ch));

	}
}
