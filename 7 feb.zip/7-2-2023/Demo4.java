// program showing the concept of wrapper class utility methods

import java.util.Scanner;
class Demo4
{
    public static void main(String args[])
    {
        Integer obj = new Integer(130);
        System.out.println("int : "+obj.intValue());
        System.out.println("float : "+obj.floatValue());
        System.out.println("byte : "+obj.byteValue());
        System.out.println("short : "+obj.shortValue());
        System.out.println("long : "+obj.longValue());
        System.out.println("double : "+obj.doubleValue());

    }
}
