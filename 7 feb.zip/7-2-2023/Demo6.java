// program showing the concept of wrapper class utility methods
// toString()

import java.util.Scanner;
class Demo6
{
    public static void main(String args[])
    {
        Integer obj = 122;
        System.out.println("string : "+obj.toString());
        String str = Integer.toString(43);
        System.out.println("string : "+str);
    }
}
