 class Example
{
    public static void main(String args[])
    {
        int y;
        String str="990";
       y= Integer.parseInt(str);
       System.out.println(y);

    }
}