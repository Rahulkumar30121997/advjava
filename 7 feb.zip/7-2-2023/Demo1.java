import java.util.Scanner;
class Demo1
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
         String m_no=null; 
         {
            System.out.println("Enter mobile number");
               m_no=sc.nextLine();
               String regex="\\d{10}";
            System.out.println("Mobile number is :"+m_no);
            System.out.println("is this number is Valid number :"+m_no.matches(regex));
         }
    }
}