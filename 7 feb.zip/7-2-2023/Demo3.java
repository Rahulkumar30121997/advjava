// program showing the concept of mobile number validation

import java.util.Scanner;
class Demo3
{
    static void validateMobileNumber(String number)
    {
        boolean status = true;
        if(number.length()!=10)
            status = false;
        else
        {
            if(number.charAt(0)=='6' || number.charAt(0)=='7' || number.charAt(0)=='8' || number.charAt(0)=='9')
            {
                for(int i=0;i<10;i++)
                {
                    char  ch = number.charAt(i);
                    if(!Character.isDigit(ch))
                    {
                        status = false;
                        break;
                    }
                }
            }
            else
                status = false;
        }       
            String s = status ? "Valid Mobile Number" : "Invalid Mobile Number";
            System.out.println("Mobile Number : "+s); 
    }
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 10-digit mobile number : ");
        String number = sc.next();
        validateMobileNumber(number);
    }
}