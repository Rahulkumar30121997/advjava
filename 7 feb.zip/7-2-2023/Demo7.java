// program showing the concept of wrapper class utility methods
// valueOf()

import java.util.Scanner;
class Demo7
{
    public static void main(String args[])
    {
        Integer i = Integer.valueOf(123);
        System.out.println("object : "+i);

        Boolean j = Boolean.valueOf("true");
        System.out.println("object : "+j);

        Double k = Double.valueOf(65.56);
        System.out.println("object : "+k);

        System.out.println("value : "+Integer.valueOf("11",10));
/*
        1 x 2^1 + 1 x 2^ 0
        1 x 2 + 1 x 1
        2 + 1
        3
  */
    }
}
