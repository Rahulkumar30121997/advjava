// program showing the concept of wrapper class utility methods
// parseXxx()

import java.util.Scanner;
class Demo5
{
    public static void main(String args[])
    {
        System.out.println("int : "+Integer.parseInt("45"));
        System.out.println("double : "+Double.parseDouble("4.5"));
        System.out.println("short : "+Short.parseShort("4"));
        System.out.println("byte : "+Byte.parseByte("45"));
        System.out.println("boolean : "+Boolean.parseBoolean("true"));
        System.out.println("long : "+Long.parseLong("4523"));
        System.out.println("float : "+Float.parseFloat("4.5"));
    }
}
